<?php

?>
	

	<div id="logo"><img src="images/logo.png" width="284"  height="96" alt="" /></div>	


	<div id="banner">
	
	<div  id="pay" class="p">Thanh Toán Khi Nhận</div>
	<div  id="truck" class="p">Thanh Toán Khi Nhận</div>
	<div  id="return" class="p">Thanh Toán Khi Nhận</div>
	<div  id="phone" class="p">Thanh Toán Khi Nhận</div>
	<div  id="lock" class="p">Thanh Toán Khi Nhận</div>

	</div>
<div class="clear"></div>