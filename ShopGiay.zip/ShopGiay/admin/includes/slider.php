

<div id="slider">
<div id="img">
<img src="images/banner1.jpg" width="970" height="415" alt="" /></div>
</div>