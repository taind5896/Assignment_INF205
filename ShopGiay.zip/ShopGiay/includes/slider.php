<script type="text/javascript" src="js/slider.js"></script>

<div id="slider">
<div id="img">
<div class="neoslideshow">

 <img src="images/banner1.jpg" width="970" height="415" />

  <img src="images/banner2.jpg"  width="970" height="415"  />

  <img src="images/banner3.jpg"  width="970" height="415"  />

  <img src="images/banner4.jpg"  width="970" height="415"  />

  <img src="images/banner5.jpg"  width="970" height="415" />

</div>

</div>
</div>