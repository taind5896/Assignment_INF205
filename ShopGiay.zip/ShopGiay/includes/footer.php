<div id="marginfooter">
<div class="muc">

<span>Liên hệ</span>





<p>Địa chỉ:489 Hai Bà TRưng TP.HCM</p>
<p >Điện thoại:01889160007</ơ>
<p >FB:facebook.com/N.D.T.5896</p>
<p >Email:ductai5896@gmail.com</p>

</div>


<div class="muc">
<span>Menu</span><div id="menufooter">

<ul>
<li><a href="?mod=home">Trang chủ</a></li>
<li><a href="?mod=gioithieu">Giới thiệu</a></li>
<li><a href="?mod=products">Sản Phẩm</a></li>
<li><a href="?mod=lienhe">Liên hệ</a></li>
<li><a href="?mod=mali">Bản đồ</a></li>
<li><a href="?mod=giohang">Giở Hàng</a></li>
</ul>

</div></div>
<div class="muc">
<span>Danh mục</span><div id="danhmucfooter">
<ul >
	<li><a href="?mod=products&type=10">Converse</a>
	
	  </li>
		<li><a href="?mod=products&type=11">Nike</a>
	
	  </li>
	  <li><a href="?mod=products&type=12">Adidas</a>
	
	  </li>
	  
	  <li><a href="?mod=products&type=13">Jordan</a>
	
	  </li>
	    <li><a href="?mod=products&type=14">Thể Thao</a>
	
	  </li>
	</ul>



</div></div>
<div class="muc">
<span>Tìm kiếm</span>
<div id="search">

<label>Search</label>
<input type="text" name="txtSearchText"  id="text" value="" />
<input type="submit" name="btnSearch" value="Tìm Kiếm" id="button" />

</div></div>
<div class="clear"></div>
</div>
