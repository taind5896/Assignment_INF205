<div id=thongbao>
<div class="order_success">ĐƠN HÀNG CỦA BẠN ĐÃ ĐƯỢC GỬI ĐI</div>
	<div class="order_success_img"><img border="0" alt="" src="images/deliverry.png" /></div>
	<div class="back_to_home_page"><a href="index.php">Trở về trang chủ</a></div>
	</div>