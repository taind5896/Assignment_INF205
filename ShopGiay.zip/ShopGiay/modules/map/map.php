<h3>Bản Đồ</h3>

	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3919.250618601444!2d106.6841651!3d10.7921073!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317528d2f24adafd%3A0x5b1191995fcb49b0!2zNDg5IEhhaSBCw6AgVHLGsG5nLCBwaMaw4budbmcgOCwgUXXhuq1uIDMsIEjhu5MgQ2jDrSBNaW5oLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1470736907593" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
					    <br />
				      <small>Xem <a href="https://www.google.com/maps/place/489+Hai+B%C3%A0+Tr%C6%B0ng,+ph%C6%B0%E1%BB%9Dng+8,+Qu%E1%BA%ADn+3,+H%E1%BB%93+Ch%C3%AD+Minh,+Vi%E1%BB%87t+Nam/@10.7921073,106.6841651,17z/data=!4m5!3m4!1s0x317528d2f24adafd:0x5b1191995fcb49b0!8m2!3d10.79212!4d106.6863429">TP Hồ Chí Minh - Việt Nam</a> ở bản đồ lớn hơn</small><br />
				
